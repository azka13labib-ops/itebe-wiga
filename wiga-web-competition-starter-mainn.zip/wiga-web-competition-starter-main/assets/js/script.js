/* =======================================================================
  COPYRIGHT (c) 2025 - PANITIA DIES NATALIS 38 ITB WIDYA GAMA LUMAJANG
  Lomba Web Design & Development (SMARTVERSE 2025)
  
  ⚠️ PERINGATAN PENTING:
  DILARANG MENGHAPUS KOMENTAR INI.
  File ini adalah bagian dari Starter Pack resmi lomba.
=======================================================================
*/


// Starter JavaScript
console.log("Project berhasil dimuat!");

// Contoh seleksi elemen menggunakan prefix class wajib
const pageTitle = document.querySelector('.wg38_page_title');

if(pageTitle) {
    console.log("Judul halaman ini adalah: " + pageTitle.innerText);
}

// Silakan tambahkan logika interaktifitas di bawah ini